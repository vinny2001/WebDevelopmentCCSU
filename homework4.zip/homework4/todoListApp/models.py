from django.db import models
import datetime

# Create your models here.

class Task(models.Model):
    task = models.CharField(max_length=100)
    date = models.DateTimeField(auto_now_add=True)

