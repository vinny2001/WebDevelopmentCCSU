from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Task
from .forms import TaskForm

## To View
def index(request):
    tasks = Task.objects.all()
    context = {'tasks': tasks}
    return render(request, 'index.html', context)

## To Create
def add(request):
    # Create a form instance and populate it with data from the request
    form = TaskForm(request.POST or None, auto_id=False)
    # check whether it's valid:
    if form.is_valid():
        # save the record into the db
        form.save()
        # after saving redirect to view_product page
        return redirect('index')

    context = {'form': form}
    return render(request,"add.html", context)

## To Update
def update(request, task_id):
    # Get the product based on its id
    task = Task.objects.get(id=task_id)
    # populate a form instance with data from the data on the database
    # instance=product allows to update the record rather than creating a new record when save method is called
    form = TaskForm(request.POST or None, instance=task, auto_id=False)

    # check whether it's valid:
    if form.is_valid():
        # update the record in the db
        form.save()
        # after updating redirect to view_product page
        return redirect("index")

    context = {'form': form}
    return render(request, "update.html", context)

## To Delete
def delete(request, task_id):
    task = Task.objects.get(id=task_id)
    task.delete()
    return redirect('index')

def search(request):
    term = request.GET.get('search-term')
    todos = Task.objects.filter(task__icontains=term)
    context = {'tasks': todos}
    return render(request, 'index.html', context)



